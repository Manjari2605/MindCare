const mongoose = require('mongoose');

const moodSchema = new mongoose.Schema({
  email: { type: String, required: true },
  mood: { type: Number, required: true },
  emotions: [String],
  notes: String,
  createdAt: { type: Date, default: Date.now }
});

module.exports = mongoose.model('Mood', moodSchema);