const mongoose = require('mongoose');

const profileSchema = new mongoose.Schema({
  personalInfo: {
    firstName: String,
    lastName: String,
    email: String,
    phone: String,
    dateOfBirth: String,
    avatar: String
  },
  academicInfo: {
    university: String,
    studentId: String,
    year: String,
    major: String,
    gpa: String
  },
  mentalHealthInfo: {
    previousTherapy: String,
    currentMedications: String,
    concerns: [String],
    goals: [String],
    preferences: {
      sessionType: String,
      frequency: String,
      genderPreference: String
    }
  },
  preferences: {
    notifications: {
      moodReminders: Boolean,
      appointmentReminders: Boolean,
      wellnessUpdates: Boolean
    },
    privacy: {
      shareAnonymousData: Boolean,
      allowResearch: Boolean
    }
  }
});

module.exports = mongoose.model('Profile', profileSchema);
