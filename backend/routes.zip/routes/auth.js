const express = require('express');
const User = require('../models/User');
const router = express.Router();


// Register new user with username, email, and password
router.post('/register', async (req, res) => {
  const { username, email, password } = req.body;
  try {
    const user = new User({ username, email, password });
    await user.save();
    res.status(201).json({ message: 'User registered successfully' });
  } catch (err) {
    if (err.code === 11000) {
      // Duplicate key error
      const field = Object.keys(err.keyPattern)[0];
      return res.status(400).json({ error: `${field.charAt(0).toUpperCase() + field.slice(1)} already exists` });
    }
    res.status(400).json({ error: err.message });
  }
});


// Simple login (by username or email)
router.post('/login', async (req, res) => {
  const { username, email, password } = req.body;
  try {
    // Allow login by username or email
    const user = await User.findOne({
      $or: [
        { username: username || null },
        { email: email || null }
      ],
      password
    });
    if (!user) return res.status(401).json({ error: 'Invalid credentials' });
    res.json({ message: 'Login successful', user: { username: user.username, email: user.email } });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

module.exports = router;
