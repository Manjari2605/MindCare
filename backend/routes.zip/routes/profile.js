const express = require('express');
const Profile = require('../models/Profile');
const router = express.Router();


// Save profile
// Upsert profile by email (update if exists, insert if not)
router.post('/', async (req, res) => {
  try {
    const email = req.body.personalInfo?.email;
    if (!email) {
      return res.status(400).json({ error: 'Email is required in personalInfo' });
    }
    const updatedProfile = await Profile.findOneAndUpdate(
      { 'personalInfo.email': email },
      req.body,
      { new: true, upsert: true, setDefaultsOnInsert: true }
    );
    res.status(201).json({ message: 'Profile saved successfully', profile: updatedProfile });
  } catch (err) {
    res.status(400).json({ error: err.message });
  }
});

// Get profile by email (or all profiles if no query)
router.get('/', async (req, res) => {
  try {
    const { email } = req.query;
    let profiles;
    if (email) {
      profiles = await Profile.find({ 'personalInfo.email': email });
    } else {
      profiles = await Profile.find();
    }
    res.json(profiles);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

module.exports = router;
